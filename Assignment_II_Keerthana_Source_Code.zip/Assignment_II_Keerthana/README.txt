ASSIGNMENT II – REWORKED SOURCE CODE
Contains three separate solutions matching the three questions in the supplied assignment:
Q1_Registration – HTML/CSS/JavaScript registration form and client-side validation.
Q2_PHP_Admin – PHP/MySQL student CRUD and upload manager.
Q3_Java_Servlet – Java Servlet/JSP/JDBC student profile portal with session filter.

The page design and naming have been changed while keeping the assignment requirements.
Read each folder's README.txt before running it. Q2 and Q3 share the campus_records database schema.
Important: Q1 only validates in the browser. Q2 requires XAMPP. Q3 requires Maven and Tomcat 9.
