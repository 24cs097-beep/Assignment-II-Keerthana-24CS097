<?php require "db.php";if($_SERVER['REQUEST_METHOD']!=='POST') {header("Location: index.php");exit;}$id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);if(!$id)exit("Invalid ID");
$st=$conn->prepare("SELECT file_path FROM student_files WHERE student_id=?");$st->bind_param("i",$id);$st->execute();$res=$st->get_result();$paths=[];while($r=$res->fetch_assoc())$paths[]=$r['file_path'];
$st=$conn->prepare("DELETE FROM students WHERE id=?");$st->bind_param("i",$id);$st->execute();foreach($paths as $p){if(preg_match('#\Auploads/(images|documents)/[a-f0-9]{32}\.(jpg|png|webp|pdf|doc|docx)\z#i',$p)&&is_file(__DIR__."/".$p))unlink(__DIR__."/".$p);}header("Location: index.php");
?>
