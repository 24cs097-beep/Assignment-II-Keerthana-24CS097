QUESTION 2 – PHP + MYSQL STUDENT ADMIN PANEL
1. Install XAMPP and start Apache and MySQL.
2. Copy Q2_PHP_Admin into C:/xampp/htdocs/ (folder name can be admin).
3. Open http://localhost/phpmyadmin and import database.sql.
4. Ensure db.php database name is campus_records; default XAMPP root password is blank.
5. Create uploads/images and uploads/documents folders. Make them writable by PHP.
6. Visit http://localhost/admin/ (or your folder name).
Features: add, view, edit, delete, unique roll number, image/document upload and metadata.
Uploads: images max 2 MB; documents max 5 MB.
For a real deployment, add administrator authentication, CSRF protection and stricter server configuration.
