<?php
require "db.php"; $error="";
function uploadOne($key,$folder,$types,$limit){
 if(empty($_FILES[$key]['name'])) return null;
 $f=$_FILES[$key]; if($f['error']!==UPLOAD_ERR_OK) throw new Exception("Upload failed.");
 if($f['size']>$limit) throw new Exception("File exceeds allowed size.");
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
 if(!isset($types[$mime])) throw new Exception("Unsupported file format.");
 $name=bin2hex(random_bytes(16)).".".$types[$mime]; $rel="uploads/$folder/$name";
 if(!move_uploaded_file($f['tmp_name'],__DIR__."/".$rel)) throw new Exception("Could not store file.");
 return ["original"=>basename($f['name']),"stored"=>$name,"path"=>$rel,"mime"=>$mime];
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $saved=[];
 try{
  $name=trim($_POST['name']??'');$roll=trim($_POST['roll_number']??'');$course=trim($_POST['course']??'');$email=trim($_POST['email']??'');$phone=trim($_POST['phone']??'');
  if(!$name||!$roll||!$course) throw new Exception("Name, roll number and course are required.");
  if($email && !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new Exception("Enter a valid email.");
  $image=uploadOne('photo','images',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'],2*1024*1024); if($image)$saved[]=$image['path'];
  $doc=uploadOne('document','documents',['application/pdf'=>'pdf','application/msword'=>'doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document'=>'docx'],5*1024*1024);if($doc)$saved[]=$doc['path'];
  $conn->begin_transaction();
  $st=$conn->prepare("INSERT INTO students(name,roll_number,course,email,phone) VALUES(?,?,?,?,?)");$st->bind_param("sssss",$name,$roll,$course,$email,$phone);$st->execute();$id=$conn->insert_id;
  foreach([$image,$doc] as $f){if($f){$st=$conn->prepare("INSERT INTO student_files(student_id,original_name,stored_name,file_path,file_type) VALUES(?,?,?,?,?)");$st->bind_param("issss",$id,$f['original'],$f['stored'],$f['path'],$f['mime']);$st->execute();}}
  $conn->commit();header("Location: view.php?id=".$id);exit;
 }catch(Throwable $e){try{$conn->rollback();}catch(Throwable $x){}foreach($saved as $p)if(is_file(__DIR__."/".$p))unlink(__DIR__."/".$p);$error=$e instanceof mysqli_sql_exception && $e->getCode()==1062?"Roll number already exists.":$e->getMessage();}
}
?>
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Add student</title><link rel="stylesheet" href="style.css"></head><body><main class="shell"><h1>Add student profile</h1><?php if($error): ?><p class="error"><?= h($error) ?></p><?php endif; ?><form method="post" enctype="multipart/form-data">
<label>Student name *</label><input name="name" required maxlength="100"><label>Roll number *</label><input name="roll_number" required maxlength="30"><label>Course *</label><input name="course" required maxlength="100"><label>Email</label><input name="email" type="email"><label>Phone</label><input name="phone"><label>Profile image (JPG/PNG/WebP, max 2 MB)</label><input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp"><label>Certificate (PDF/DOC/DOCX, max 5 MB)</label><input type="file" name="document" accept=".pdf,.doc,.docx"><button>Save profile</button> <a class="btn secondary" href="index.php">Cancel</a></form></main></body></html>
