<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = new mysqli("localhost", "root", "", "campus_records");
$conn->set_charset("utf8mb4");
function h($value) { return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8"); }
?>
