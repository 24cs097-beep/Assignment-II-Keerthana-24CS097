package com.campus;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;import java.io.*;import java.sql.*;
@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {
 protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
  int id;try{id=Integer.parseInt(req.getParameter("id"));}catch(Exception e){res.sendError(400,"Invalid student ID");return;}
  try(Connection c=DB.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM students WHERE id=?")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(!r.next()){res.sendError(404);return;}
   req.setAttribute("id",id);req.setAttribute("name",r.getString("name"));req.setAttribute("roll",r.getString("roll_number"));req.setAttribute("course",r.getString("course"));req.setAttribute("email",r.getString("email"));
  }}
  try(Connection c=DB.getConnection();PreparedStatement p=c.prepareStatement("SELECT id,original_name,file_type FROM student_files WHERE student_id=?")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){java.util.List<java.util.Map<String,Object>> files=new java.util.ArrayList<>();while(r.next()){java.util.Map<String,Object> f=new java.util.HashMap<>();f.put("id",r.getInt("id"));f.put("name",r.getString("original_name"));f.put("type",r.getString("file_type"));files.add(f);}req.setAttribute("files",files);}}
  catch(SQLException e){throw new ServletException(e);}req.getRequestDispatcher("/WEB-INF/profile.jsp").forward(req,res);
 }
}
