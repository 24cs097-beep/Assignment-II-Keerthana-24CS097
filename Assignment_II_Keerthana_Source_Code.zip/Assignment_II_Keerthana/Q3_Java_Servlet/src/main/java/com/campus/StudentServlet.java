package com.campus;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;import java.io.*;import java.sql.*;
@WebServlet("/students")
public class StudentServlet extends HttpServlet {
 protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
  try(Connection c=DB.getConnection();PreparedStatement p=c.prepareStatement("SELECT id,name,roll_number,course,email FROM students ORDER BY id DESC");ResultSet r=p.executeQuery()){
   java.util.List<java.util.Map<String,Object>> list=new java.util.ArrayList<>();
   while(r.next()){java.util.Map<String,Object> m=new java.util.HashMap<>();m.put("id",r.getInt("id"));m.put("name",r.getString("name"));m.put("roll",r.getString("roll_number"));m.put("course",r.getString("course"));m.put("email",r.getString("email"));list.add(m);}
   req.setAttribute("students",list);req.getRequestDispatcher("/WEB-INF/students.jsp").forward(req,res);
  }catch(SQLException e){throw new ServletException(e);}
 }
}
