package com.campus;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;import java.io.*;
@WebFilter(urlPatterns={"/students","/profile","/docs","/logout"})
public class AuthFilter implements Filter {
 public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
  HttpServletRequest req=(HttpServletRequest)request;HttpServletResponse res=(HttpServletResponse)response;HttpSession s=req.getSession(false);
  if(s==null||s.getAttribute("adminUser")==null)res.sendRedirect(req.getContextPath()+"/login");else chain.doFilter(request,response);
 }
}
