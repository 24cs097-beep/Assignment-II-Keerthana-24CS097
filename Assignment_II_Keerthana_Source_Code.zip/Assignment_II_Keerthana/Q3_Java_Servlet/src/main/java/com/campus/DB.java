package com.campus;
import java.sql.*;
public class DB {
 public static Connection getConnection() throws SQLException {
  return DriverManager.getConnection("jdbc:mysql://localhost:3306/campus_records?useSSL=false&serverTimezone=UTC","root","");
 }
}
