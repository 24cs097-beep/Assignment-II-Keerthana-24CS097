package com.campus;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;import java.io.*;
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet { protected void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException{HttpSession s=req.getSession(false);if(s!=null)s.invalidate();res.sendRedirect(req.getContextPath()+"/login");} }
