package com.campus;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;import java.io.*;import java.sql.*;
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
 protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{req.getRequestDispatcher("/WEB-INF/login.jsp").forward(req,res);}
 protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
  String user=req.getParameter("username"),pass=req.getParameter("password");
  // Demo credentials for the assignment: admin / campus123
  if("admin".equals(user)&&"campus123".equals(pass)){HttpSession s=req.getSession(true);s.setAttribute("adminUser",user);s.setMaxInactiveInterval(1800);res.sendRedirect(req.getContextPath()+"/students");}
  else{req.setAttribute("error","Invalid username or password.");req.getRequestDispatcher("/WEB-INF/login.jsp").forward(req,res);}
 }
}
