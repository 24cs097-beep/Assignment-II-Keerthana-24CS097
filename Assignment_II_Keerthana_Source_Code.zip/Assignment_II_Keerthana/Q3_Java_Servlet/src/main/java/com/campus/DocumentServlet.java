package com.campus;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;import java.io.*;import java.sql.*;
@WebServlet("/docs")
public class DocumentServlet extends HttpServlet {
 protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
  int id;try{id=Integer.parseInt(req.getParameter("id"));}catch(Exception e){res.sendError(400);return;}
  try(Connection c=DB.getConnection();PreparedStatement p=c.prepareStatement("SELECT file_path,file_type,original_name FROM student_files WHERE id=?")){
   p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(!r.next()){res.sendError(404);return;}
    String relative=r.getString("file_path");File base=new File(getServletContext().getRealPath("/")).getCanonicalFile();File file=new File(base,relative).getCanonicalFile();
    if(!file.getPath().startsWith(base.getPath()+File.separator)||!file.isFile()){res.sendError(404);return;}
    res.setContentType(r.getString("file_type"));res.setHeader("Content-Disposition","inline; filename=\""+r.getString("original_name").replace("\"","")+"\"");
    try(InputStream in=new FileInputStream(file);OutputStream out=res.getOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
   }
  }catch(SQLException e){throw new ServletException(e);}
 }
}
