QUESTION 3 – JAVA SERVLET/JSP STUDENT PORTAL
Requirements: JDK 8+, Maven, Apache Tomcat 9, MySQL 8, and the Q2 database tables.
1. Run Q2 database.sql first. It creates campus_records, students and student_files.
2. Put uploaded files in the web application's deployed uploads/images and uploads/documents folders, preserving paths saved in student_files.file_path. For a simple local demo, copy the Q2 uploads folder into the deployed web application root.
3. Update DB credentials/port in src/main/java/com/campus/DB.java if needed.
4. Build from this folder: mvn clean package
5. Deploy target/student-portal.war to Tomcat 9 webapps; start Tomcat.
6. Open http://localhost:8080/student-portal/login
Demo login: admin / campus123
This is a teaching/demo login. Replace it with database-backed password hashing before real deployment.
Servlets: /login, /students, /profile, /docs, /logout. AuthFilter protects portal pages.
