document.getElementById("registrationForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const roll = document.getElementById("roll").value.trim();
  const email = document.getElementById("email").value.trim();
  const course = document.getElementById("course").value;
  const password = document.getElementById("password").value;
  const file = document.getElementById("document").files[0];
  const error = document.getElementById("error");
  const message = document.getElementById("message");
  error.textContent = ""; message.textContent = "";
  if (!name || !roll || !email || !course || !password) {
    error.textContent = "Please complete all required fields."; return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    error.textContent = "Enter a valid email address."; return;
  }
  if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/.test(password)) {
    error.textContent = "Password must contain 8 characters, uppercase, lowercase, number and symbol."; return;
  }
  if (file) {
    const allowed = ["application/pdf", "image/jpeg", "image/png"];
    if (!allowed.includes(file.type)) { error.textContent = "Only PDF, JPG and PNG files are accepted."; return; }
    if (file.size > 2 * 1024 * 1024) { error.textContent = "File size must be below 2 MB."; return; }
  }
  message.textContent = "Registration details validated successfully!";
});
