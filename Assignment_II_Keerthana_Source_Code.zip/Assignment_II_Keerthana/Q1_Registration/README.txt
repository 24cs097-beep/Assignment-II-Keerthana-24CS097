QUESTION 1 – STUDENT REGISTRATION
Run: Open index.html in a browser.
Files: index.html, style.css, script.js.
Note: This assignment demonstrates client-side validation only. It does not save records to a server/database.
